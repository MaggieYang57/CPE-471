/* Release code for program 1 CPE 471 Fall 2016 */

#include <iostream>
#include <string>
#include <vector>
#include <memory>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#include "Image.h"

// This allows you to skip the `std::` in front of C++ standard library
// functions. You can also say `using std::cout` to be more selective.
// You should never do this in a header file.
using namespace std;

int g_width, g_height;

/*
   Helper function you will want all quarter
   Given a vector of shapes which has already been read from an obj file
   resize all vertices to the range [-1, 1]
 */
void resize_obj(std::vector<tinyobj::shape_t> &shapes){
   float minX, minY, minZ;
   float maxX, maxY, maxZ;
   float scaleX, scaleY, scaleZ;
   float shiftX, shiftY, shiftZ;
   float epsilon = 0.001;

   minX = minY = minZ = 1.1754E+38F;
   maxX = maxY = maxZ = -1.1754E+38F;

   //Go through all vertices to determine min and max of each dimension
   for (size_t i = 0; i < shapes.size(); i++) {
      for (size_t v = 0; v < shapes[i].mesh.positions.size() / 3; v++) {
         if(shapes[i].mesh.positions[3*v+0] < minX) minX = shapes[i].mesh.positions[3*v+0];
         if(shapes[i].mesh.positions[3*v+0] > maxX) maxX = shapes[i].mesh.positions[3*v+0];

         if(shapes[i].mesh.positions[3*v+1] < minY) minY = shapes[i].mesh.positions[3*v+1];
         if(shapes[i].mesh.positions[3*v+1] > maxY) maxY = shapes[i].mesh.positions[3*v+1];

         if(shapes[i].mesh.positions[3*v+2] < minZ) minZ = shapes[i].mesh.positions[3*v+2];
         if(shapes[i].mesh.positions[3*v+2] > maxZ) maxZ = shapes[i].mesh.positions[3*v+2];
      }
   }

	//From min and max compute necessary scale and shift for each dimension
   float maxExtent, xExtent, yExtent, zExtent;
   xExtent = maxX-minX;
   yExtent = maxY-minY;
   zExtent = maxZ-minZ;
   if (xExtent >= yExtent && xExtent >= zExtent) {
      maxExtent = xExtent;
   }
   if (yExtent >= xExtent && yExtent >= zExtent) {
      maxExtent = yExtent;
   }
   if (zExtent >= xExtent && zExtent >= yExtent) {
      maxExtent = zExtent;
   }
   scaleX = 2.0 /maxExtent;
   shiftX = minX + (xExtent/ 2.0);
   scaleY = 2.0 / maxExtent;
   shiftY = minY + (yExtent / 2.0);
   scaleZ = 2.0/ maxExtent;
   shiftZ = minZ + (zExtent)/2.0;

   //Go through all verticies shift and scale them
   for (size_t i = 0; i < shapes.size(); i++) {
      for (size_t v = 0; v < shapes[i].mesh.positions.size() / 3; v++) {
         shapes[i].mesh.positions[3*v+0] = (shapes[i].mesh.positions[3*v+0] - shiftX) * scaleX;
         assert(shapes[i].mesh.positions[3*v+0] >= -1.0 - epsilon);
         assert(shapes[i].mesh.positions[3*v+0] <= 1.0 + epsilon);
         shapes[i].mesh.positions[3*v+1] = (shapes[i].mesh.positions[3*v+1] - shiftY) * scaleY;
         assert(shapes[i].mesh.positions[3*v+1] >= -1.0 - epsilon);
         assert(shapes[i].mesh.positions[3*v+1] <= 1.0 + epsilon);
         shapes[i].mesh.positions[3*v+2] = (shapes[i].mesh.positions[3*v+2] - shiftZ) * scaleZ;
         assert(shapes[i].mesh.positions[3*v+2] >= -1.0 - epsilon);
         assert(shapes[i].mesh.positions[3*v+2] <= 1.0 + epsilon);
      }
   }
}

struct Point
{
	float x, y ,z;
} point;

struct Box
{
	float xmin, xmax;
	float ymin, ymax;
} box;

struct Triangle
{
	Point p1, p2, p3;
} triangle;

float maximum(float a, float b, float c)
{
	float compared = a;
	if (b > compared)
		compared = b;
	if (c > compared)
		compared = c;
	return compared;
}

float minimum(float a, float b, float c)
{
	float compared = a;
	if (b < compared)
		compared = b;
	if (c < compared)
		compared = c;
	return compared;
}

float getTriangleArea(Point p1, Point p2, Point p3)
{
	return float(abs(( p1.x*(p2.y - p3.y) + p2.x*(p3.y - p1.y) + p3.x*(p1.y - p2.y) ) / 2.0));
}

Triangle createTriangle(Point p1, Point p2, Point p3)
{
	Triangle triangle;

	triangle.p1 = p1;
	triangle.p2 = p2;
	triangle.p3 = p3;

	return triangle;
}

Box createBoundingBox(Triangle triangle)
{
	Box box;

	float xmin = minimum(triangle.p1.x, triangle.p2.x, triangle.p3.x);
	float ymin = minimum(triangle.p1.y, triangle.p2.y, triangle.p3.y);
	float xmax = maximum(triangle.p1.x, triangle.p2.x, triangle.p3.x);
	float ymax = maximum(triangle.p1.y, triangle.p2.y, triangle.p3.y);

	box.xmin = xmin;
	box.xmax = xmax;
	box.ymin = ymin;
	box.ymax = ymax;

	return box;
} 

/*bool point_inside_trigon(Point s, Point a, Point b, Point c)
{
	int as_x = s.x - a.x;
	int as_y = s.y - a.y;

	bool s_ab = (b.x - a.x) * as_y - (b.y - a.y) * as_x > 0;

	if ((c.x - a.x) * as_y - (c.y - a.y) * as_x > 0 == s_ab) return false;

	if ((c.x - b.x) * (s.y - b.y) - (c.y - b.y) * (s.x - b.x) > 0 != s_ab) return false;

	return true;
}function still gave cracks*/

int main(int argc, char** argv)
{
	/*if(argc < 3) {
	  cout << "Usage: Assignment1 meshfile imagefile" << endl;
	  return 0;
	}	
	// OBJ filename
	char color[100] = "color";
	string meshName(argv[1]);
	string redResult(argv[2]);
	string colorResult(strcat(color,argv[2]));
	*/
	
	string meshName("bunny.obj");
	string result("bunnyresult.png");

	//set g_width and g_height appropriately!
	g_width = g_height = 600;

	//create an image
	auto image = make_shared<Image>(g_width, g_height);

	// triangle buffer 123 234
	vector<unsigned int> triBuf;
	// position buffer ABCD (individual vertices)
	vector<float> posBuf;
	// Some obj files contain material information.
	// We'll ignore them for this assignment.
	vector<tinyobj::shape_t> shapes; // geometry
	vector<tinyobj::material_t> objMaterials; // material
	string errStr;

	bool rc = tinyobj::LoadObj(shapes, objMaterials, errStr, meshName.c_str());
	/* error checking on read */
	if (!rc) {
		cerr << errStr << endl;
	}
	else {
		//keep this code to resize your object to be within -1 -> 1
		resize_obj(shapes);
		posBuf = shapes[0].mesh.positions;
		triBuf = shapes[0].mesh.indices;
	}

	cout << "Number of vertices: " << posBuf.size() / 3 << endl;
	cout << "Number of triangles: " << triBuf.size() / 3 << endl;

	//TODO add code to iterate through each triangle and rasterize it 

	/*Image zBuffer(g_width, g_height);
	for (int x = 0; x < g_width; x++)
	{
		for (int y = 0; y < g_height; y++)
		{
			zBuffer.setPixel(x, y, 255, 0, 0);
			zBuffer.pixels[x * 3 + y * 3 * g_width] = 255;
		}
	}*/
	vector <vector<float> > zBuffer;
	for (int i = 0; i < g_width; i++) 
	{
		vector<float> initz(g_height, -1);
		zBuffer.push_back(initz);
	}

	Point* vertices = new Point[posBuf.size() / 3];
	int c = 0;
	for (int i = 0; i < posBuf.size(); i += 3) // collecting vertices of obj file
	{
		vertices[c].x = posBuf[i + 0];
		vertices[c].y = posBuf[i + 1];
		vertices[c].z = posBuf[i + 2];
		c++;
	}
	
	for (int i = 0; i < triBuf.size(); i+=3) //for each triangle (tribuf HOLDS posbuf)
	{
		Point p1, p2, p3;
		p1 = vertices[triBuf[i + 0]];
		p2 = vertices[triBuf[i + 1]];
		p3 = vertices[triBuf[i + 2]];

		// convert to pixel range for picture
		p1.x = (p1.x + 1) * 300;
		p1.y = (p1.y + 1) * 300;

		p2.x = (p2.x + 1) * 300;
		p2.y = (p2.y + 1) * 300;

		p3.x = (p3.x + 1) * 300;
		p3.y = (p3.y + 1) * 300;
		
		Triangle triangle = createTriangle(p1, p2, p3);
		Box boundingBox = createBoundingBox(triangle);

		float bigArea = getTriangleArea(p1, p2, p3);

		for (float currentx = boundingBox.xmin; currentx < boundingBox.xmax; currentx++)
		{
			for (float currenty = boundingBox.ymin; currenty < boundingBox.ymax; currenty++)
			{
				Point current;
				current.x = currentx;
				current.y = currenty;
			
				//find area of small triangles
				float small1 = getTriangleArea(triangle.p1, triangle.p2, current);
				float small2 = getTriangleArea(triangle.p2, triangle.p3, current);
				float small3 = getTriangleArea(triangle.p1, triangle.p3, current);

				float alpha = small1 / bigArea;
				float beta = small2 / bigArea;
				float gamma = small3 / bigArea;

				//calculate zbuf and compare
				//[-1, 1] ->[255, 0]
				//if ((alpha >= 0 && alpha <= 1) && (beta >= 0 && beta <= 1) && (gamma >= 0 && gamma <= 1))
				if(alpha + beta + gamma <= 1.15) //if within triangle
				//if(point_inside_trigon(current, triangle.p1, triangle.p2, triangle.p3) == true)
				{
					float currentz = (beta * triangle.p1.z) + (gamma * triangle.p2.z) + (alpha * triangle.p3.z);
					int cred = (currentz + 1) * (255/2); //use z-coordinate to calculate shading --> convert to rgb
					
					if (currentz > zBuffer[currentx][currenty])// --> -1 = 255, 1= 0
					{
						zBuffer[currentx][currenty] = currentz;
						image->setPixel(int(currentx), int(currenty), cred, 0, 0);
					}
				}
			}
		}
	}
	image->writeToFile(result);
	return 0;
}