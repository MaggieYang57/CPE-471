/* Release code for program 1 CPE 471 Fall 2016 */

#include <iostream>
#include <string>
#include <vector>
#include <memory>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#include "Image.h"

// This allows you to skip the `std::` in front of C++ standard library
// functions. You can also say `using std::cout` to be more selective.
// You should never do this in a header file.
using namespace std;

int g_width, g_height;

/*
   Helper function you will want all quarter
   Given a vector of shapes which has already been read from an obj file
   resize all vertices to the range [-1, 1]
 */
void resize_obj(std::vector<tinyobj::shape_t> &shapes){
   float minX, minY, minZ;
   float maxX, maxY, maxZ;
   float scaleX, scaleY, scaleZ;
   float shiftX, shiftY, shiftZ;
   float epsilon = 0.001;

   minX = minY = minZ = 1.1754E+38F;
   maxX = maxY = maxZ = -1.1754E+38F;

   //Go through all vertices to determine min and max of each dimension
   for (size_t i = 0; i < shapes.size(); i++) {
      for (size_t v = 0; v < shapes[i].mesh.positions.size() / 3; v++) {
         if(shapes[i].mesh.positions[3*v+0] < minX) minX = shapes[i].mesh.positions[3*v+0];
         if(shapes[i].mesh.positions[3*v+0] > maxX) maxX = shapes[i].mesh.positions[3*v+0];

         if(shapes[i].mesh.positions[3*v+1] < minY) minY = shapes[i].mesh.positions[3*v+1];
         if(shapes[i].mesh.positions[3*v+1] > maxY) maxY = shapes[i].mesh.positions[3*v+1];

         if(shapes[i].mesh.positions[3*v+2] < minZ) minZ = shapes[i].mesh.positions[3*v+2];
         if(shapes[i].mesh.positions[3*v+2] > maxZ) maxZ = shapes[i].mesh.positions[3*v+2];
      }
   }

	//From min and max compute necessary scale and shift for each dimension
   float maxExtent, xExtent, yExtent, zExtent;
   xExtent = maxX-minX;
   yExtent = maxY-minY;
   zExtent = maxZ-minZ;
   if (xExtent >= yExtent && xExtent >= zExtent) {
      maxExtent = xExtent;
   }
   if (yExtent >= xExtent && yExtent >= zExtent) {
      maxExtent = yExtent;
   }
   if (zExtent >= xExtent && zExtent >= yExtent) {
      maxExtent = zExtent;
   }
   scaleX = 2.0 /maxExtent;
   shiftX = minX + (xExtent/ 2.0);
   scaleY = 2.0 / maxExtent;
   shiftY = minY + (yExtent / 2.0);
   scaleZ = 2.0/ maxExtent;
   shiftZ = minZ + (zExtent)/2.0;

   //Go through all verticies shift and scale them
   for (size_t i = 0; i < shapes.size(); i++) {
      for (size_t v = 0; v < shapes[i].mesh.positions.size() / 3; v++) {
         shapes[i].mesh.positions[3*v+0] = (shapes[i].mesh.positions[3*v+0] - shiftX) * scaleX;
         assert(shapes[i].mesh.positions[3*v+0] >= -1.0 - epsilon);
         assert(shapes[i].mesh.positions[3*v+0] <= 1.0 + epsilon);
         shapes[i].mesh.positions[3*v+1] = (shapes[i].mesh.positions[3*v+1] - shiftY) * scaleY;
         assert(shapes[i].mesh.positions[3*v+1] >= -1.0 - epsilon);
         assert(shapes[i].mesh.positions[3*v+1] <= 1.0 + epsilon);
         shapes[i].mesh.positions[3*v+2] = (shapes[i].mesh.positions[3*v+2] - shiftZ) * scaleZ;
         assert(shapes[i].mesh.positions[3*v+2] >= -1.0 - epsilon);
         assert(shapes[i].mesh.positions[3*v+2] <= 1.0 + epsilon);
      }
   }
}

struct Point
{
	float x, y;
} point;

struct Box
{
	float xmin, xmax;
	float ymin, ymax;
} box;

struct Triangle
{
	Point p1, p2, p3;
} triangle;

float maximum(float a, float b, float c)
{
	float compared = a;
	if (b > compared)
		compared = b;
	if (c > compared)
		compared = c;
	return compared;
}

float minimum(float a, float b, float c)
{
	float compared = a;
	if (b < compared)
		compared = b;
	if (c < compared)
		compared = c;
	return compared;
}

float getTriangleArea(Point p1, Point p2, Point p3)
{
	return float(abs(( p1.x*(p2.y - p3.y) + p2.x*(p3.y - p1.y) + p3.x*(p1.y - p2.y) ) / 2.0));
}

Triangle createTriangle(Point p1, Point p2, Point p3)
{
	Triangle triangle;

	triangle.p1 = p1;
	triangle.p2 = p2;
	triangle.p3 = p3;

	return triangle;
}

Box createBoundingBox(Triangle triangle)
{
	Box box;

	float xmin = minimum(triangle.p1.x, triangle.p2.x, triangle.p3.x);
	float ymin = minimum(triangle.p1.y, triangle.p2.y, triangle.p3.y);
	float xmax = maximum(triangle.p1.x, triangle.p2.x, triangle.p3.x);
	float ymax = maximum(triangle.p1.y, triangle.p2.y, triangle.p3.y);

	box.xmin = xmin;
	box.xmax = xmax;
	box.ymin = ymin;
	box.ymax = ymax;

	return box;
}


int main(int argc, char** argv)
{
	/*if(argc < 3) {
	  cout << "Usage: Assignment1 meshfile imagefile" << endl;
	  return 0;
	}	
	// OBJ filename
	char color[100] = "color";
	string meshName(argv[1]);
	string redResult(argv[2]);
	string colorResult(strcat(color,argv[2]));
	*/
	
	string meshName("tri.obj");
	string redResult("redresult.png");
	string colorResult("colorresult.png");

	//set g_width and g_height appropriately!
	g_width = g_height = 100;

	//create an image
	auto redimage = make_shared<Image>(g_width, g_height);
	auto colorimage = make_shared<Image>(g_width, g_height);

	// triangle buffer
	vector<unsigned int> triBuf;
	// position buffer
	vector<float> posBuf;
	// Some obj files contain material information.
	// We'll ignore them for this assignment.
	vector<tinyobj::shape_t> shapes; // geometry
	vector<tinyobj::material_t> objMaterials; // material
	string errStr;

	bool rc = tinyobj::LoadObj(shapes, objMaterials, errStr, meshName.c_str());
	/* error checking on read */
	if (!rc) {
		cerr << errStr << endl;
	}
	else {
		//keep this code to resize your object to be within -1 -> 1
		resize_obj(shapes);
		posBuf = shapes[0].mesh.positions;
		triBuf = shapes[0].mesh.indices;
	}

	cout << "Number of vertices: " << posBuf.size() / 3 << endl;
	cout << "Number of triangles: " << triBuf.size() / 3 << endl;

	//TODO add code to iterate through each triangle and rasterize it 

	//given range is from -1 to 1 --> convert to pixels
	/*for (size_t v = 0; v < shapes[i].mesh.positions.size() / 3; v++)
	{
		float x = shapes[i].mesh.positions[3 * v + 0] + 1) *50;
		float y = shapes[i].mesh.positions[3 * v + 1];
	}*/

	Point p1, p2, p3;
	p1.x = (shapes[0].mesh.positions[3 * 0 + 0] + 1) * 50;
	p1.y = (shapes[0].mesh.positions[3 * 0 + 1] + 1) * 50;
	p2.x = (shapes[0].mesh.positions[3 * 1 + 0] + 1) * 50;
	p2.y = (shapes[0].mesh.positions[3 * 1 + 1] + 1) * 50;
	p3.x = (shapes[0].mesh.positions[3 * 2 + 0] + 1) * 50;
	p3.y = (shapes[0].mesh.positions[3 * 2 + 1] + 1) * 50;

	Triangle triangle = createTriangle(p1, p2, p3);
	Box boundingBox = createBoundingBox(triangle);
	
	float bigArea = getTriangleArea(p1, p2, p3);

	for (float currentx = boundingBox.xmin ; currentx < boundingBox.xmax; currentx++)
	{
		for (float currenty = boundingBox.ymin ; currenty < boundingBox.ymax; currenty++)
		{
			Point current;
			current.x = currentx;
			current.y = currenty;

			//find area of small triangles
			float small1 = getTriangleArea(triangle.p1, triangle.p2, current);
			float small2 = getTriangleArea(triangle.p2, triangle.p3, current);
			float small3 = getTriangleArea(triangle.p1, triangle.p3, current);
			
			//add it up  --> if it is equal to big triangle--> color red
			if ((small1 + small2 + small3) == bigArea)
			{
				redimage->setPixel(int(currentx), int(currenty), 255, 0, 0);

				float alpha = small1 / bigArea; // top --> blue
				float beta = small2 / bigArea; // left --> red
				float gamma = small3 / bigArea; // right --> green

				colorimage->setPixel(int(currentx), int(currenty), beta * 255, gamma * 255, alpha * 255);
			}
		}
	}
	redimage->writeToFile(redResult);
	colorimage->writeToFile(colorResult);

	return 0;
}
